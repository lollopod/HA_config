"""All constants related to the shopping list component."""
DOMAIN = "shopping_list"
